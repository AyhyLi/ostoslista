const mysql = require("mysql");
const yhteys = mysql.createConnection({
                                        host     : "localhost",
                                        user     : "root",
                                        password : "",
                                        database : "ostoslista"
                                    });

yhteys.connect((err) => {
    if(!err) {
        console.log("Tietokantayhteys avattu");    
    } else {
        throw `Virhe yhdistettäessä tietokantaan: ${err}`;    
    }
});

module.exports = {
    "haeListat":(callback)=>{
        let sql="SELECT DISTINCT listanNimi, kayttajaId FROM listat";
        
        yhteys.query(sql, (err, data)=>{
            callback(err, data);
        });
    },
    
    "haeLista":(listanNimi, callback) => {
        
        let sql="SELECT * FROM listat WHERE listanNimi = ?";
        
        yhteys.query(sql, [listanNimi], (err, data)=>{
            callback(err, data);
        });
    },
    
    "lisaaLista":(listanTiedot, callback)=>{
        let sql="INSERT INTO listat (kayttajaId, listanNimi, sisalto, ostettu) VALUES (?, ?,'Kirjoita oma ostos tähän', 0)";
        
        yhteys.query(sql, [listanTiedot.id, listanTiedot.nimi], (err)=>{
            callback(err);
        });
    },
    
    "lisaaListaan":(uudetTiedot, callback)=>{
        let sql="INSERT INTO listat (kayttajaId, listanNimi, sisalto, ostettu) VALUES (?, ?, ?, ?)";
        
        yhteys.query(sql, [uudetTiedot.kayttaja, uudetTiedot.lista, uudetTiedot.sisalto, uudetTiedot.ostettu], (err)=>{
            callback(err);
        });
    },
    
    "poistaListasta":(poistettava, callback)=>{
        let sql=`DELETE FROM listat WHERE id = ${poistettava}`;
        
        yhteys.query(sql, (err)=>{
           callback(err); 
        });
    },
    
    "tallennaMuokkaus":(paivitetty, callback)=>{
        let sql;
        
        if(paivitetty.ostettu){
            sql=`UPDATE listat SET sisalto = "${paivitetty.sisalto}", ostettu = 1 WHERE id = ?`;
        }
        else{
            sql=`UPDATE listat SET sisalto = "${paivitetty.sisalto}", ostettu = 0 WHERE id = ?`;
        }
        
        yhteys.query(sql, [paivitetty.id],(err)=>{
            callback(err);
        });
    },
    
    "muokkaaOstettu":(tiedot, callback)=>{
        let sql;
        
        if(tiedot.ostettu == "true"){
            sql="UPDATE listat SET ostettu = 0 WHERE id = ?";
        }
        else{
            sql="UPDATE listat SET ostettu = 1 WHERE id = ?";
        }
        
        yhteys.query(sql, [tiedot.id], (err)=>{
           callback(err); 
        });
    }
};